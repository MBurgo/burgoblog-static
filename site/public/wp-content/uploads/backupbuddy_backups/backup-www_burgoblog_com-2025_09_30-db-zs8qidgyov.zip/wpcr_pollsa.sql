CREATE TABLE `wpcr_pollsa` (  `polla_aid` int(10) NOT NULL AUTO_INCREMENT,  `polla_qid` int(10) NOT NULL,  `polla_answers` varchar(200) NOT NULL,  `polla_votes` int(10) NOT NULL,  PRIMARY KEY (`polla_aid`)) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40000 ALTER TABLE `wpcr_pollsa` DISABLE KEYS */;
INSERT INTO `wpcr_pollsa` VALUES('1', '1', 'I don\\\'t care how the site looks, as long as I can read the text.', '4');
INSERT INTO `wpcr_pollsa` VALUES('2', '1', 'Not much, as long as it\\\'s not offensively bad.', '1');
INSERT INTO `wpcr_pollsa` VALUES('3', '1', 'It plays a small part.', '1');
INSERT INTO `wpcr_pollsa` VALUES('4', '1', 'Your look is a large part of the identity, and one of the reasons I read Burgo\\\'s Music Blog.', '1');
/*!40000 ALTER TABLE `wpcr_pollsa` ENABLE KEYS */;
