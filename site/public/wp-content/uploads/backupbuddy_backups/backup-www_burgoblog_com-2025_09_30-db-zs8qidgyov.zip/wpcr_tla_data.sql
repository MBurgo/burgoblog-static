CREATE TABLE `wpcr_tla_data` (  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `post_id` bigint(20) unsigned NOT NULL,  `url` text NOT NULL,  `text` text NOT NULL,  `before_text` text NOT NULL,  `after_text` text NOT NULL,  `rss_text` text NOT NULL,  `rss_before_text` text NOT NULL,  `rss_after_text` text NOT NULL,  `rss_prefix` varchar(255) NOT NULL,  PRIMARY KEY (`id`),  KEY `post_id` (`post_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40000 ALTER TABLE `wpcr_tla_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpcr_tla_data` ENABLE KEYS */;
