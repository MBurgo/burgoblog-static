CREATE TABLE `wpcr_pollsq` (  `pollq_id` int(10) NOT NULL AUTO_INCREMENT,  `pollq_question` varchar(200) NOT NULL,  `pollq_timestamp` varchar(20) NOT NULL,  `pollq_totalvotes` int(10) NOT NULL,  `pollq_active` tinyint(1) NOT NULL DEFAULT 1,  `pollq_expiry` varchar(20) NOT NULL,  `pollq_multiple` tinyint(3) NOT NULL,  `pollq_totalvoters` int(10) NOT NULL,  PRIMARY KEY (`pollq_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40000 ALTER TABLE `wpcr_pollsq` DISABLE KEYS */;
INSERT INTO `wpcr_pollsq` VALUES('1', 'How much a part does the design of Burgo\\\'s Music Blog play in your reading it?', '1196228491', '7', '1', '', '0', '7');
/*!40000 ALTER TABLE `wpcr_pollsq` ENABLE KEYS */;
