CREATE TABLE `wpcr_tla_rss_map` (  `post_id` int(10) unsigned NOT NULL,  `advertisement` text NOT NULL,  PRIMARY KEY (`post_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40000 ALTER TABLE `wpcr_tla_rss_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpcr_tla_rss_map` ENABLE KEYS */;
