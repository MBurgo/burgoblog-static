CREATE TABLE `wpcr_litespeed_img_optming` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,  `optm_status` tinyint(4) NOT NULL DEFAULT 0,  `src` varchar(1000) NOT NULL DEFAULT '',  `server_info` text NOT NULL,  PRIMARY KEY (`id`),  KEY `post_id` (`post_id`),  KEY `optm_status` (`optm_status`),  KEY `src` (`src`(191))) ENGINE=MyISAM AUTO_INCREMENT=1830 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `wpcr_litespeed_img_optming` DISABLE KEYS */;
INSERT INTO `wpcr_litespeed_img_optming` VALUES('43', '810', '3', './joe-pug21-150x150.jpg', '');
INSERT INTO `wpcr_litespeed_img_optming` VALUES('1115', '2019', '3', './bon2-120x100.jpg', '');
/*!40000 ALTER TABLE `wpcr_litespeed_img_optming` ENABLE KEYS */;
