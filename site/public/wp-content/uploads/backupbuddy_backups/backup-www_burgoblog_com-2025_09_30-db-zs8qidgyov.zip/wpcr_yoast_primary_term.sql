CREATE TABLE `wpcr_yoast_primary_term` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `post_id` bigint(20) DEFAULT NULL,  `term_id` bigint(20) DEFAULT NULL,  `taxonomy` varchar(32) NOT NULL,  `created_at` datetime DEFAULT NULL,  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),  `blog_id` bigint(20) NOT NULL DEFAULT 1,  PRIMARY KEY (`id`),  KEY `post_taxonomy` (`post_id`,`taxonomy`),  KEY `post_term` (`post_id`,`term_id`)) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `wpcr_yoast_primary_term` DISABLE KEYS */;
INSERT INTO `wpcr_yoast_primary_term` VALUES('1', '2464', '791', 'category', '2022-01-06 02:41:33', '2022-01-09 03:39:30', '1');
INSERT INTO `wpcr_yoast_primary_term` VALUES('2', '2453', '790', 'category', '2022-01-08 00:44:31', '2024-02-15 11:43:57', '1');
INSERT INTO `wpcr_yoast_primary_term` VALUES('3', '2443', '458', 'category', '2022-01-08 00:44:31', '2024-02-15 11:43:56', '1');
INSERT INTO `wpcr_yoast_primary_term` VALUES('4', '2396', '790', 'category', '2022-01-08 00:44:31', '2024-02-15 11:43:57', '1');
INSERT INTO `wpcr_yoast_primary_term` VALUES('5', '2504', '742', 'category', '2022-01-08 00:48:59', '2022-01-09 11:34:59', '1');
/*!40000 ALTER TABLE `wpcr_yoast_primary_term` ENABLE KEYS */;
