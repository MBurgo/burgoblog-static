CREATE TABLE `wpcr_termmeta` (  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,  `meta_key` varchar(255) DEFAULT NULL,  `meta_value` longtext DEFAULT NULL,  PRIMARY KEY (`meta_id`),  KEY `term_id` (`term_id`),  KEY `meta_key` (`meta_key`(191))) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wpcr_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpcr_termmeta` ENABLE KEYS */;
