CREATE TABLE `wpcr_woo_custom_nav_menus` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `menu_name` text NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40000 ALTER TABLE `wpcr_woo_custom_nav_menus` DISABLE KEYS */;
INSERT INTO `wpcr_woo_custom_nav_menus` VALUES('1', 'Woo Menu 1');
INSERT INTO `wpcr_woo_custom_nav_menus` VALUES('2', 'Woo Menu 2');
/*!40000 ALTER TABLE `wpcr_woo_custom_nav_menus` ENABLE KEYS */;
